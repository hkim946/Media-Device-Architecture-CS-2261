// The array of character data
extern const unsigned char fontdata_6x8[12288];