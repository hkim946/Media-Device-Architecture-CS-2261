Space Invader of Some Sort!

In order to start the game, press START (enter key).
Move the rocket around using the LEFT and RIGHT keys (A and D keys),
and press A (L key) in order to fire a bullet. 

There are blocks that block the bullets from being fired at the aliens. 
You must move the rocket in a position where it is not blocked by a block and
fire at the aliens.

Every alien you kill, you will earn 10 points. In order to win, you must earn
130 points.

If you would like to pause during the game, press START (enter key).
If you would like to lose the game, press B (K key).
If you would like to restart the game once you have won or lost, press START (enter key).

ENJOY!


*P.S. to TA who is grading this,
 Oddly, when I go to the pause state and return back to the game state, the objects that are not sprites, as in the green blocks, rocket, and bullets turn black, and I was not able to figure out why. Before I had the state backgrounds as a plain black background with drawString4 to indicate the state, but those also turned black once I paused and returned to the game, which is why I switched them to sprites. If I could get feedback on why this is happening, that would be great. Thank you!