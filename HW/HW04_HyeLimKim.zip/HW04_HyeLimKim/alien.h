
//{{BLOCK(alien)

//======================================================================
//
//	alien, 16x16@8, 
//	+ palette 256 entries, not compressed
//	+ bitmap not compressed
//	Total size: 512 + 256 = 768
//
//	Time-stamp: 2021-03-08, 21:59:06
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_ALIEN_H
#define GRIT_ALIEN_H

#define alienBitmapLen 256
extern const unsigned short alienBitmap[128];

#define alienPalLen 512
extern const unsigned short alienPal[256];

#endif // GRIT_ALIEN_H

//}}BLOCK(alien)
